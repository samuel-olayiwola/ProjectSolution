﻿
using System;
namespace Project.Controllers.Resources.Requests
{
    public class FilterRequest
    {
        public string? FilterProperty { get; set; } 
        public string? FilterValue { get; set; }
    }
}

