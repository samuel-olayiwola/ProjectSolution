﻿using System;
namespace Project.Controllers.Resources.Responses
{
    public class ErrorResponse
    {
        public string error { get; set; }
    }
}

